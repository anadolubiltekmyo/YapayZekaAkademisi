// Navbar scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Mobile menu toggle
const mobileBtn = document.querySelector('.mobile-menu-btn');
const navLinks = document.querySelector('.nav-links');

mobileBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    
    // Toggle icon
    const icon = mobileBtn.querySelector('i');
    if (navLinks.classList.contains('active')) {
        icon.classList.remove('fa-bars');
        icon.classList.add('fa-times');
    } else {
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
    }
});

// Close mobile menu when a link is clicked
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
        const icon = mobileBtn.querySelector('i');
        icon.classList.remove('fa-times');
        icon.classList.add('fa-bars');
    });
});

// --- Weather Widget ---
const openWeatherApiKey = 'ABC'; // Lütfen içerisine OpenWeatherMap API key ekleyin
const weatherCity = 'Istanbul';
const weatherApiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${weatherCity}&units=metric&lang=tr&appid=${openWeatherApiKey}`;

async function fetchWeather() {
    try {
        const response = await fetch(weatherApiUrl);
        if (response.ok) {
            const data = await response.json();
            const temp = Math.round(data.main.temp);
            const iconCode = data.weather[0].icon;
            
            document.getElementById('weatherTemp').textContent = `${temp}°C`;
            const iconImg = document.getElementById('weatherIcon');
            const defaultIcon = document.getElementById('weatherIconDefault');
            
            iconImg.src = `https://openweathermap.org/img/wn/${iconCode}.png`;
            iconImg.style.display = 'block';
            if (defaultIcon) defaultIcon.style.display = 'none';
        } else {
            console.error('Hava durumu verisi alınamadı:', response.status);
        }
    } catch (error) {
        console.error('Hava durumu API hatası:', error);
    }
}

if (openWeatherApiKey && openWeatherApiKey !== 'YOUR_API_KEY_HERE') {
    fetchWeather();
} else {
    console.warn("OpenWeatherMap API Key eksik. Hava durumu widget'ı çalışması için script.js dosyasına API anahtarını ekleyin.");
}
