var http = require('http');
var https = require('https');
var fs = require('fs');
var path = require('path');

var PORT = 8080;
var USGS_URL = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_month.geojson';

var MIME = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8'
};

// Cache: USGS verisini 5 dk önbellekle
var cache = { data: null, time: 0 };
var CACHE_TTL = 5 * 60 * 1000;

function fetchUSGS(callback) {
    var now = Date.now();
    if (cache.data && (now - cache.time) < CACHE_TTL) {
        return callback(null, cache.data);
    }

    https.get(USGS_URL, function (res) {
        var body = '';
        res.on('data', function (chunk) { body += chunk; });
        res.on('end', function () {
            cache.data = body;
            cache.time = Date.now();
            callback(null, body);
        });
    }).on('error', function (err) {
        callback(err, null);
    });
}

var server = http.createServer(function (req, res) {
    // API proxy endpoint
    if (req.url === '/api/earthquakes') {
        fetchUSGS(function (err, data) {
            if (err) {
                res.writeHead(502, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: err.message }));
                return;
            }
            res.writeHead(200, {
                'Content-Type': 'application/json; charset=utf-8',
                'Access-Control-Allow-Origin': '*'
            });
            res.end(data);
        });
        return;
    }

    // Statik dosya sunumu
    var filePath = req.url === '/' ? '/index.html' : req.url;
    var fullPath = path.join(__dirname, filePath);
    var ext = path.extname(fullPath);

    fs.readFile(fullPath, function (err, content) {
        if (err) {
            res.writeHead(404);
            res.end('Not Found');
            return;
        }
        res.writeHead(200, { 'Content-Type': MIME[ext] || 'text/plain' });
        res.end(content);
    });
});

server.listen(PORT, function () {
    console.log('🌍 Deprem Dashboard: http://localhost:' + PORT);
    console.log('📡 API Proxy:        http://localhost:' + PORT + '/api/earthquakes');
});
