/* ========================================
   Wiki Image Collage – Application Logic
   ======================================== */

(function () {
  'use strict';

  // --- DOM Elements ---
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');
  const imageCountSlider = document.getElementById('imageCount');
  const imageCountValue = document.getElementById('imageCountValue');
  const canvasSizeSelect = document.getElementById('canvasSize');
  const shuffleBtn = document.getElementById('shuffleBtn');
  const downloadBtn = document.getElementById('downloadBtn');
  const controls = document.getElementById('controls');
  const status = document.getElementById('status');
  const placeholder = document.getElementById('placeholder');
  const loader = document.getElementById('loader');
  const canvas = document.getElementById('collageCanvas');
  const ctx = canvas.getContext('2d');

  // --- State ---
  let currentImages = []; // Array of { url, width, height }
  let currentQuery = '';

  // --- Helpers ---
  function setStatus(msg, type = 'info') {
    status.textContent = msg;
    status.className = 'status ' + type;
  }

  function clearStatus() {
    status.textContent = '';
    status.className = 'status';
  }

  function showLoader(show) {
    loader.classList.toggle('visible', show);
  }

  function showPlaceholder(show) {
    placeholder.classList.toggle('hidden', !show);
  }

  function showCanvas(show) {
    canvas.classList.toggle('visible', show);
  }

  function showControls(show) {
    controls.classList.toggle('visible', show);
  }

  function getCanvasSize() {
    const val = canvasSizeSelect.value.split('x');
    return { width: parseInt(val[0]), height: parseInt(val[1]) };
  }

  // --- Wikimedia Commons API ---
  async function searchImages(query, limit) {
    const params = new URLSearchParams({
      action: 'query',
      generator: 'search',
      gsrsearch: query,
      gsrnamespace: '6',
      gsrlimit: String(Math.min(limit * 2, 50)), // request more to filter
      prop: 'imageinfo',
      iiprop: 'url|size|mime',
      iiurlwidth: '800', // request thumbnail at 800px wide
      format: 'json',
      origin: '*'
    });

    const url = `https://commons.wikimedia.org/w/api.php?${params}`;
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();

    if (!data.query || !data.query.pages) {
      return [];
    }

    const pages = Object.values(data.query.pages);
    const images = [];

    for (const page of pages) {
      if (!page.imageinfo || page.imageinfo.length === 0) continue;
      const info = page.imageinfo[0];

      // Only include raster images
      if (!info.mime || !info.mime.startsWith('image/')) continue;
      if (info.mime === 'image/svg+xml') continue; // skip SVGs
      if (info.mime === 'image/tiff') continue; // skip TIFFs

      const imgUrl = info.thumburl || info.url;
      if (!imgUrl) continue;

      images.push({
        url: imgUrl,
        width: info.thumbwidth || info.width,
        height: info.thumbheight || info.height,
        title: page.title || ''
      });

      if (images.length >= limit) break;
    }

    return images;
  }

  // --- Image Loading ---
  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error(`Failed to load: ${src}`));
      img.src = src;
    });
  }

  async function loadAllImages(imageData) {
    const results = await Promise.allSettled(
      imageData.map(d => loadImage(d.url))
    );

    const loaded = [];
    results.forEach((result, i) => {
      if (result.status === 'fulfilled') {
        loaded.push({
          img: result.value,
          data: imageData[i]
        });
      }
    });

    return loaded;
  }

  // --- Collage Rendering ---
  function renderCollage(loadedImages) {
    const size = getCanvasSize();
    canvas.width = size.width;
    canvas.height = size.height;

    // Background – subtle gradient
    const bgGrad = ctx.createLinearGradient(0, 0, size.width, size.height);
    bgGrad.addColorStop(0, '#1a1a2e');
    bgGrad.addColorStop(0.5, '#16213e');
    bgGrad.addColorStop(1, '#0f3460');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, size.width, size.height);

    // Add subtle noise/texture via random dots
    ctx.globalAlpha = 0.03;
    for (let i = 0; i < 3000; i++) {
      ctx.fillStyle = Math.random() > 0.5 ? '#ffffff' : '#6366f1';
      ctx.fillRect(
        Math.random() * size.width,
        Math.random() * size.height,
        1, 1
      );
    }
    ctx.globalAlpha = 1;

    if (loadedImages.length === 0) return;

    // Shuffle images for random layering
    const shuffled = [...loadedImages].sort(() => Math.random() - 0.5);

    // Calculate placements
    const placements = shuffled.map((item) => {
      const img = item.img;
      const aspect = img.naturalWidth / img.naturalHeight;

      // Random size – images between 15% and 35% of canvas width
      const minW = size.width * 0.15;
      const maxW = size.width * 0.35;
      const drawWidth = minW + Math.random() * (maxW - minW);
      const drawHeight = drawWidth / aspect;

      // Random position – allow edges to bleed slightly off canvas
      const margin = drawWidth * 0.3;
      const x = -margin + Math.random() * (size.width + margin * 0.5);
      const y = -margin + Math.random() * (size.height + margin * 0.5);

      // Random rotation
      const rotation = (Math.random() - 0.5) * 30 * (Math.PI / 180); // ±15°

      return { img, x, y, drawWidth, drawHeight, rotation };
    });

    // Draw each image
    placements.forEach((p) => {
      ctx.save();

      // Translate to center of image for rotation
      const cx = p.x + p.drawWidth / 2;
      const cy = p.y + p.drawHeight / 2;
      ctx.translate(cx, cy);
      ctx.rotate(p.rotation);

      // Draw shadow
      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
      ctx.shadowBlur = 20;
      ctx.shadowOffsetX = 4;
      ctx.shadowOffsetY = 6;

      // Draw white photo border (polaroid style)
      const borderW = 10;
      const borderBottom = 30;
      ctx.fillStyle = '#ffffff';
      roundRect(
        ctx,
        -p.drawWidth / 2 - borderW,
        -p.drawHeight / 2 - borderW,
        p.drawWidth + borderW * 2,
        p.drawHeight + borderW + borderBottom,
        4
      );
      ctx.fill();

      // Reset shadow for image
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;

      // Draw the image
      ctx.drawImage(
        p.img,
        -p.drawWidth / 2,
        -p.drawHeight / 2,
        p.drawWidth,
        p.drawHeight
      );

      ctx.restore();
    });
  }

  // Rounded rectangle helper
  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  // --- Main Search & Render Flow ---
  async function performSearch() {
    const query = searchInput.value.trim();
    if (!query) {
      setStatus('Please enter a search term.', 'warning');
      searchInput.focus();
      return;
    }

    currentQuery = query;
    const limit = parseInt(imageCountSlider.value);

    // UI state
    showPlaceholder(false);
    showCanvas(false);
    showLoader(true);
    showControls(false);
    clearStatus();
    setStatus(`Searching for "${query}"…`, 'info');

    try {
      // Step 1: Search API
      const imageData = await searchImages(query, limit);

      if (imageData.length === 0) {
        showLoader(false);
        showPlaceholder(true);
        setStatus(`No images found for "${query}". Try a different search term.`, 'warning');
        return;
      }

      setStatus(`Loading ${imageData.length} images…`, 'info');
      currentImages = imageData;

      // Step 2: Load images
      const loadedImages = await loadAllImages(imageData);

      if (loadedImages.length === 0) {
        showLoader(false);
        showPlaceholder(true);
        setStatus('Failed to load images. This may be a CORS issue. Try a different query.', 'error');
        return;
      }

      // Step 3: Render collage
      renderCollage(loadedImages);

      showLoader(false);
      showCanvas(true);
      showControls(true);
      setStatus(`Collage created with ${loadedImages.length} images ✨`, 'success');

    } catch (err) {
      console.error('Search error:', err);
      showLoader(false);
      showPlaceholder(true);
      setStatus(`Error: ${err.message}`, 'error');
    }
  }

  // --- Shuffle (re-render with same images) ---
  async function shuffleCollage() {
    if (currentImages.length === 0) return;

    showLoader(true);
    setStatus('Shuffling layout…', 'info');

    // Small delay so the loader shows
    await new Promise(r => setTimeout(r, 100));

    const loadedImages = await loadAllImages(currentImages);
    renderCollage(loadedImages);

    showLoader(false);
    showCanvas(true);
    setStatus(`Layout shuffled ✨`, 'success');
  }

  // --- Download ---
  function downloadCollage() {
    if (!canvas.width || !canvas.height) return;

    try {
      const link = document.createElement('a');
      link.download = `collage-${currentQuery.replace(/\s+/g, '-')}-${Date.now()}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      setStatus('Collage downloaded!', 'success');
    } catch (err) {
      setStatus('Download failed – images may have CORS restrictions.', 'error');
    }
  }

  // --- Event Listeners ---
  searchBtn.addEventListener('click', performSearch);

  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      performSearch();
    }
  });

  imageCountSlider.addEventListener('input', () => {
    imageCountValue.textContent = imageCountSlider.value;
  });

  shuffleBtn.addEventListener('click', shuffleCollage);
  downloadBtn.addEventListener('click', downloadCollage);

  // Canvas size change re-renders
  canvasSizeSelect.addEventListener('change', async () => {
    if (currentImages.length > 0) {
      await shuffleCollage();
    }
  });

})();
