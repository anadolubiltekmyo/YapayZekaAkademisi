// ===== DOM Elements =====
const urlInput = document.getElementById('wikiUrl');
const generateBtn = document.getElementById('generateBtn');
const btnText = generateBtn.querySelector('.btn-text');
const btnLoader = generateBtn.querySelector('.btn-loader');
const errorMsg = document.getElementById('errorMsg');
const cloudSection = document.getElementById('cloudSection');
const articleTitleEl = document.getElementById('articleTitle');
const canvas = document.getElementById('wordCloudCanvas');
const ctx = canvas.getContext('2d');
const tooltip = document.getElementById('tooltip');
const downloadBtn = document.getElementById('downloadBtn');
const regenerateBtn = document.getElementById('regenerateBtn');
const statWords = document.getElementById('statWords');
const statTotal = document.getElementById('statTotal');
const statTop = document.getElementById('statTop');

// ===== State =====
let currentWords = []; // Array of {text, count, size, x, y, width, height, color}
let rawFrequencies = null;
let articleTitle = '';

// ===== Color Palettes =====
const PALETTES = [
    ['#a78bfa', '#818cf8', '#38bdf8', '#22d3ee', '#34d399', '#6ee7b7'],
    ['#f472b6', '#fb7185', '#f97316', '#fbbf24', '#a3e635', '#34d399'],
    ['#c084fc', '#e879f9', '#f472b6', '#fb923c', '#facc15', '#4ade80'],
    ['#60a5fa', '#38bdf8', '#22d3ee', '#2dd4bf', '#a78bfa', '#e879f9'],
    ['#fb7185', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899'],
];

// ===== Stop Words =====
const STOP_WORDS = new Set([
    'the','be','to','of','and','a','in','that','have','i','it','for','not','on','with',
    'he','as','you','do','at','this','but','his','by','from','they','we','say','her',
    'she','or','an','will','my','one','all','would','there','their','what','so','up',
    'out','if','about','who','get','which','go','me','when','make','can','like','time',
    'no','just','him','know','take','people','into','year','your','good','some','could',
    'them','see','other','than','then','now','look','only','come','its','over','think',
    'also','back','after','use','two','how','our','work','first','well','way','even',
    'new','want','because','any','these','give','day','most','us','is','was','are',
    'were','been','has','had','did','does','being','having','am','more','very','much',
    'may','such','many','those','each','own','same','through','between','both','still',
    'where','should','while','before','under','here','again','off','down','during',
    'found','used','however','since','until','without','per','within','often','since',
    'around','became','using','known','made','called','part','based','including','another',
    'several','among','became','whether','later','early','being','along','against','al',
    'thus','upon','whom','above','across','towards','already','rather','though','yet',
    'become','began','given','toward','might','must','shall','need','let','thing','every',
    'too','less','enough','never','always','right','old','number','great','long','small',
    'large','possible','last','big','little','different','few','three','second','third',
    'set','far','next','still','got','keep','went','put','run','away','end','went',
    'did','been','had','may','also','said','one','two','three','four','five','six',
    'seven','eight','nine','ten','first','second','third','last','new','old','high',
    'low','many','much','few','more','most','other','well','form','de','la','le',
    'et','en','ref','isbn','pp','vol','no','ed','see','also','may',
    'cite','web','retrieved','http','https','www','com','org','html','php','pdf',
    'january','february','march','april','june','july','august','september','october',
    'november','december','category','citation','needed','external','links','references',
    'original','archived',
]);

// ===== Wikipedia URL Parser =====
function parseWikiUrl(url) {
    url = url.trim();
    // Match patterns like:
    //   https://en.wikipedia.org/wiki/Article_Title
    //   https://en.m.wikipedia.org/wiki/Article_Title
    //   en.wikipedia.org/wiki/Article_Title
    const patterns = [
        /(?:https?:\/\/)?([a-z]{2,3})(?:\.m)?\.wikipedia\.org\/wiki\/(.+?)(?:#.*)?$/i,
    ];
    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) {
            return { lang: match[1], title: decodeURIComponent(match[2].replace(/_/g, ' ')), rawTitle: match[2] };
        }
    }
    return null;
}

// ===== Fetch Wikipedia Article Text =====
async function fetchArticleText(lang, rawTitle) {
    const apiUrl = `https://${lang}.wikipedia.org/w/api.php?` + new URLSearchParams({
        action: 'parse',
        page: rawTitle,
        prop: 'text',
        format: 'json',
        origin: '*',
        disabletoc: '1',
    });

    const response = await fetch(apiUrl);
    if (!response.ok) throw new Error(`Wikipedia API error: ${response.status}`);

    const data = await response.json();
    if (data.error) throw new Error(data.error.info || 'Article not found');

    const html = data.parse.text['*'];
    const displayTitle = data.parse.title;

    // Parse HTML to extract text content
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    // Remove unwanted elements
    doc.querySelectorAll('table, .infobox, .sidebar, .navbox, .mw-editsection, sup, .reference, .reflist, style, script, .mw-empty-elt, .noprint, .metadata').forEach(el => el.remove());

    const text = doc.body.textContent || '';
    return { text, displayTitle };
}

// ===== Text Processing =====
function computeFrequencies(text) {
    // Tokenize: split on non-word characters, keep only alphabetic tokens >= 3 chars
    const tokens = text
        .toLowerCase()
        .split(/[^a-zA-ZÀ-ÖØ-öø-ÿ]+/)
        .filter(w => w.length >= 3 && !STOP_WORDS.has(w));

    const freq = {};
    let totalWords = 0;
    for (const w of tokens) {
        freq[w] = (freq[w] || 0) + 1;
        totalWords++;
    }

    // Sort by frequency descending and take top 120 words
    const sorted = Object.entries(freq)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 120);

    return { sorted, uniqueCount: Object.keys(freq).length, totalWords };
}

// ===== Word Cloud Rendering =====
function renderWordCloud(sortedWords) {
    const dpr = window.devicePixelRatio || 1;
    const container = canvas.parentElement;
    const w = Math.min(container.clientWidth - 48, 860);
    const h = Math.max(400, Math.min(w * 0.55, 500));

    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Clear
    ctx.clearRect(0, 0, w, h);

    if (sortedWords.length === 0) return [];

    const palette = PALETTES[Math.floor(Math.random() * PALETTES.length)];

    const maxCount = sortedWords[0][1];
    const minCount = sortedWords[sortedWords.length - 1][1];
    const range = Math.max(maxCount - minCount, 1);

    // Size range
    const minSize = 12;
    const maxSize = Math.min(w / 8, 72);

    const placedWords = [];
    const occupied = []; // bounding boxes

    const centerX = w / 2;
    const centerY = h / 2;

    for (let i = 0; i < sortedWords.length; i++) {
        const [word, count] = sortedWords[i];
        const t = (count - minCount) / range;
        const fontSize = minSize + t * (maxSize - minSize);
        const fontWeight = t > 0.5 ? 700 : (t > 0.2 ? 600 : 500);

        ctx.font = `${fontWeight} ${fontSize}px Inter, sans-serif`;
        const metrics = ctx.measureText(word);
        const wordW = metrics.width + 6;
        const wordH = fontSize * 1.2;

        const color = palette[i % palette.length];

        // Spiral placement
        let placed = false;
        let angle = Math.random() * Math.PI * 2;
        const angleStep = 0.3;
        let radius = 0;
        const radiusStep = 2;
        const maxRadius = Math.sqrt(centerX * centerX + centerY * centerY);

        while (radius < maxRadius) {
            const x = centerX + Math.cos(angle) * radius - wordW / 2;
            const y = centerY + Math.sin(angle) * radius - wordH / 2;

            // Check within bounds
            if (x >= 0 && y >= 0 && x + wordW <= w && y + wordH <= h) {
                // Check collision
                const box = { x, y, w: wordW, h: wordH };
                if (!hasCollision(box, occupied)) {
                    // Draw the word
                    ctx.fillStyle = color;
                    ctx.font = `${fontWeight} ${fontSize}px Inter, sans-serif`;
                    ctx.textBaseline = 'top';
                    ctx.fillText(word, x + 3, y);

                    occupied.push(box);
                    placedWords.push({
                        text: word,
                        count,
                        size: fontSize,
                        x: x,
                        y: y,
                        width: wordW,
                        height: wordH,
                        color,
                    });
                    placed = true;
                    break;
                }
            }

            angle += angleStep;
            radius += radiusStep * (angleStep / (2 * Math.PI));
        }
    }

    return placedWords;
}

function hasCollision(box, occupied) {
    const pad = 3;
    for (const o of occupied) {
        if (
            box.x < o.x + o.w + pad &&
            box.x + box.w + pad > o.x &&
            box.y < o.y + o.h + pad &&
            box.y + box.h + pad > o.y
        ) {
            return true;
        }
    }
    return false;
}

// ===== Tooltip =====
canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    let found = null;
    for (const w of currentWords) {
        if (mx >= w.x && mx <= w.x + w.width && my >= w.y && my <= w.y + w.height) {
            found = w;
            break;
        }
    }

    if (found) {
        tooltip.hidden = false;
        tooltip.innerHTML = `<strong style="color:${found.color}">${found.text}</strong> — ${found.count} occurrences`;
        tooltip.style.left = e.clientX + 12 + 'px';
        tooltip.style.top = e.clientY - 10 + 'px';
        canvas.style.cursor = 'pointer';
    } else {
        tooltip.hidden = true;
        canvas.style.cursor = 'crosshair';
    }
});

canvas.addEventListener('mouseleave', () => {
    tooltip.hidden = true;
});

canvas.addEventListener('click', (e) => {
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    for (const w of currentWords) {
        if (mx >= w.x && mx <= w.x + w.width && my >= w.y && my <= w.y + w.height) {
            window.open(`https://en.wikipedia.org/wiki/${encodeURIComponent(w.text)}`, '_blank');
            break;
        }
    }
});

// ===== Download PNG =====
downloadBtn.addEventListener('click', () => {
    const link = document.createElement('a');
    link.download = `wiki-cloud-${articleTitle.replace(/\s+/g, '-').toLowerCase()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
});

// ===== Regenerate =====
regenerateBtn.addEventListener('click', () => {
    if (rawFrequencies) {
        currentWords = renderWordCloud(rawFrequencies);
    }
});

// ===== Main Flow =====
generateBtn.addEventListener('click', generate);
urlInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') generate();
});

async function generate() {
    const url = urlInput.value.trim();
    showError('');

    const parsed = parseWikiUrl(url);
    if (!parsed) {
        showError('Please enter a valid Wikipedia article URL (e.g., https://en.wikipedia.org/wiki/Artificial_intelligence)');
        return;
    }

    setLoading(true);

    try {
        const { text, displayTitle } = await fetchArticleText(parsed.lang, parsed.rawTitle);

        if (!text || text.trim().length < 50) {
            throw new Error('The article appears to be empty or too short.');
        }

        const { sorted, uniqueCount, totalWords } = computeFrequencies(text);

        if (sorted.length < 5) {
            throw new Error('Not enough meaningful words found in the article.');
        }

        articleTitle = displayTitle;
        rawFrequencies = sorted;

        articleTitleEl.textContent = displayTitle;
        cloudSection.hidden = false;

        // Small delay for animation
        await new Promise(r => setTimeout(r, 50));
        currentWords = renderWordCloud(sorted);

        // Update stats
        statWords.textContent = uniqueCount.toLocaleString();
        statTotal.textContent = totalWords.toLocaleString();
        statTop.textContent = sorted[0][0];

        // Scroll to cloud
        cloudSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

    } catch (err) {
        showError(err.message);
    } finally {
        setLoading(false);
    }
}

function setLoading(loading) {
    generateBtn.disabled = loading;
    btnText.hidden = loading;
    btnLoader.hidden = !loading;
}

function showError(msg) {
    if (msg) {
        errorMsg.textContent = msg;
        errorMsg.hidden = false;
    } else {
        errorMsg.hidden = true;
    }
}

// ===== Resize Handler =====
let resizeTimeout;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
        if (rawFrequencies) {
            currentWords = renderWordCloud(rawFrequencies);
        }
    }, 300);
});
