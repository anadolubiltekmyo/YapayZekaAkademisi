const cells = document.querySelectorAll('.cell');
const statusText = document.getElementById('statusText');
const resetBtn = document.getElementById('resetBtn');
const playerXScoreEl = document.getElementById('scoreX');
const playerOScoreEl = document.getElementById('scoreO');
const playerXContainer = document.getElementById('playerX');
const playerOContainer = document.getElementById('playerO');
const gameOverModal = document.getElementById('gameOverModal');
const winnerText = document.getElementById('winnerText');
const playAgainBtn = document.getElementById('playAgainBtn');

const winConditions = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6]             // Diagonals
];

let options = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let running = false;
let scores = { X: 0, O: 0 };

initializeGame();

function initializeGame() {
    cells.forEach(cell => cell.addEventListener('click', cellClicked));
    resetBtn.addEventListener('click', resetBoard);
    playAgainBtn.addEventListener('click', () => {
        gameOverModal.classList.remove('show');
        resetBoard();
    });
    running = true;
    updateStatus();
}

function cellClicked() {
    const cellIndex = this.getAttribute('data-index');

    if (options[cellIndex] !== "" || !running) {
        return;
    }

    updateCell(this, cellIndex);
    checkWinner();
}

function updateCell(cell, index) {
    options[index] = currentPlayer;
    cell.textContent = currentPlayer;
    cell.classList.add(currentPlayer.toLowerCase());
}

function changePlayer() {
    currentPlayer = (currentPlayer === "X") ? "O" : "X";
    updateStatus();
    
    // Update active state in scoreboard
    if (currentPlayer === "X") {
        playerXContainer.classList.add('active');
        playerOContainer.classList.remove('active');
    } else {
        playerOContainer.classList.add('active');
        playerXContainer.classList.remove('active');
    }
}

function checkWinner() {
    let roundWon = false;
    let winningCells = [];

    for (let i = 0; i < winConditions.length; i++) {
        const condition = winConditions[i];
        const cellA = options[condition[0]];
        const cellB = options[condition[1]];
        const cellC = options[condition[2]];

        if (cellA === "" || cellB === "" || cellC === "") {
            continue;
        }
        if (cellA === cellB && cellB === cellC) {
            roundWon = true;
            winningCells = condition;
            break;
        }
    }

    if (roundWon) {
        // Highlight winning cells
        winningCells.forEach(index => {
            cells[index].classList.add('win-highlight');
        });
        
        running = false;
        scores[currentPlayer]++;
        updateScoreBoard();
        showGameOverModal(`Kazanan: <span class="highlight-${currentPlayer.toLowerCase()}">${currentPlayer}</span>!`);
    } else if (!options.includes("")) {
        running = false;
        showGameOverModal("Oyun Berabere!");
    } else {
        changePlayer();
    }
}

function updateStatus() {
    const colorClass = currentPlayer === "X" ? "highlight-x" : "highlight-o";
    statusText.innerHTML = `Sıra <span class="${colorClass}">${currentPlayer}</span>'te`;
}

function updateScoreBoard() {
    playerXScoreEl.textContent = scores.X;
    playerOScoreEl.textContent = scores.O;
}

function resetBoard() {
    currentPlayer = "X";
    options = ["", "", "", "", "", "", "", "", ""];
    updateStatus();
    
    playerXContainer.classList.add('active');
    playerOContainer.classList.remove('active');
    
    cells.forEach(cell => {
        cell.textContent = "";
        cell.classList.remove('x', 'o', 'win-highlight');
    });
    
    running = true;
}

function showGameOverModal(message) {
    winnerText.innerHTML = message;
    setTimeout(() => {
        gameOverModal.classList.add('show');
    }, 500); // Wait a bit for the win animation
}
