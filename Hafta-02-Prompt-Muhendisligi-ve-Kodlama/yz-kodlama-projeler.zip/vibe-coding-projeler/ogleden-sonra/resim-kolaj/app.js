// ========== DOM Elements ==========
const searchForm = document.getElementById('searchForm');
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const btnText = searchBtn.querySelector('.btn-text');
const btnLoader = searchBtn.querySelector('.btn-loader');
const resultInfo = document.getElementById('resultInfo');
const loadingState = document.getElementById('loadingState');
const errorState = document.getElementById('errorState');
const errorMessage = document.getElementById('errorMessage');
const retryBtn = document.getElementById('retryBtn');
const emptyState = document.getElementById('emptyState');
const collageSection = document.getElementById('collageSection');
const collageGrid = document.getElementById('collageGrid');
const loadMoreBtn = document.getElementById('loadMoreBtn');
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightboxImg');
const lightboxTitle = document.getElementById('lightboxTitle');
const lightboxLink = document.getElementById('lightboxLink');
const lightboxClose = document.getElementById('lightboxClose');
const lightboxOverlay = lightbox.querySelector('.lightbox-overlay');

// ========== State ==========
let currentQuery = '';
let continueToken = null;
let isLoading = false;

// ========== API ==========
const API_BASE = 'https://commons.wikimedia.org/w/api.php';

function buildSearchUrl(query, gsroffset = 0) {
    const params = new URLSearchParams({
        action: 'query',
        generator: 'search',
        gsrsearch: query,
        gsrnamespace: '6',
        gsrlimit: '30',
        gsroffset: gsroffset.toString(),
        prop: 'imageinfo',
        iiprop: 'url|extmetadata|mime',
        iiurlwidth: '400',
        format: 'json',
        origin: '*'
    });
    return `${API_BASE}?${params.toString()}`;
}

async function searchImages(query, gsroffset = 0) {
    const url = buildSearchUrl(query, gsroffset);
    const response = await fetch(url);
    
    if (!response.ok) {
        throw new Error(`API hatası: ${response.status}`);
    }
    
    const data = await response.json();
    return data;
}

// ========== UI State Management ==========
function showState(state) {
    loadingState.hidden = true;
    errorState.hidden = true;
    emptyState.hidden = true;
    collageSection.hidden = true;
    resultInfo.hidden = true;

    switch (state) {
        case 'loading':
            loadingState.hidden = false;
            break;
        case 'error':
            errorState.hidden = false;
            break;
        case 'empty':
            emptyState.hidden = false;
            break;
        case 'results':
            collageSection.hidden = false;
            resultInfo.hidden = false;
            break;
    }
}

function setButtonLoading(loading) {
    isLoading = loading;
    searchBtn.disabled = loading;
    btnText.hidden = loading;
    btnLoader.hidden = !loading;
}

// ========== Image Processing ==========
function extractImageData(pages) {
    if (!pages) return [];
    
    const images = [];
    
    for (const pageId of Object.keys(pages)) {
        const page = pages[pageId];
        const info = page.imageinfo?.[0];
        
        if (!info) continue;
        
        // Skip non-image files (SVGs, videos, audio etc.)
        const mime = info.mime || '';
        if (!mime.startsWith('image/') || mime === 'image/svg+xml') continue;
        
        const thumbUrl = info.thumburl || info.url;
        const fullUrl = info.url;
        const descUrl = info.descriptionurl || '';
        
        // Extract title from extmetadata or page title
        let title = page.title?.replace('File:', '').replace(/\.[^/.]+$/, '') || '';
        const extmeta = info.extmetadata;
        if (extmeta?.ObjectName?.value) {
            title = extmeta.ObjectName.value;
        }
        
        // Clean HTML from title
        title = title.replace(/<[^>]*>/g, '').trim();
        
        if (thumbUrl) {
            images.push({ thumbUrl, fullUrl, descUrl, title });
        }
    }
    
    return images;
}

function createImageCard(imageData, index) {
    const item = document.createElement('div');
    item.className = 'collage-item';
    item.style.animationDelay = `${index * 0.05}s`;
    
    const img = document.createElement('img');
    img.src = imageData.thumbUrl;
    img.alt = imageData.title;
    img.loading = 'lazy';
    
    // Handle image load errors
    img.onerror = () => {
        item.remove();
    };
    
    const overlay = document.createElement('div');
    overlay.className = 'item-overlay';
    
    const titleEl = document.createElement('p');
    titleEl.textContent = imageData.title;
    overlay.appendChild(titleEl);
    
    item.appendChild(img);
    item.appendChild(overlay);
    
    // Click to open lightbox
    item.addEventListener('click', () => {
        openLightbox(imageData);
    });
    
    return item;
}

// ========== Search Handler ==========
async function performSearch(query, append = false) {
    if (isLoading) return;
    
    currentQuery = query;
    setButtonLoading(true);
    
    if (!append) {
        collageGrid.innerHTML = '';
        continueToken = null;
        showState('loading');
    }
    
    try {
        const offset = append ? continueToken : 0;
        const data = await searchImages(query, offset);
        
        const images = extractImageData(data.query?.pages);
        
        if (images.length === 0 && !append) {
            showState('empty');
            const emptyP = emptyState.querySelector('p');
            emptyP.textContent = `"${query}" için görsel bulunamadı. Başka bir anahtar kelime deneyin.`;
            setButtonLoading(false);
            return;
        }
        
        // Store continue token for "Load More"
        if (data.continue?.gsroffset) {
            continueToken = data.continue.gsroffset;
            loadMoreBtn.hidden = false;
        } else {
            continueToken = null;
            loadMoreBtn.hidden = true;
        }
        
        // Add image cards to grid
        const fragment = document.createDocumentFragment();
        images.forEach((imgData, i) => {
            const card = createImageCard(imgData, i);
            fragment.appendChild(card);
        });
        collageGrid.appendChild(fragment);
        
        showState('results');
        
        const totalCards = collageGrid.children.length;
        resultInfo.textContent = `"${query}" için ${totalCards} görsel gösteriliyor`;
        resultInfo.hidden = false;
        
    } catch (err) {
        console.error('Search error:', err);
        if (!append) {
            showState('error');
            errorMessage.textContent = `Arama sırasında bir hata oluştu: ${err.message}`;
        }
    } finally {
        setButtonLoading(false);
    }
}

// ========== Lightbox ==========
function openLightbox(imageData) {
    lightboxImg.src = imageData.fullUrl;
    lightboxImg.alt = imageData.title;
    lightboxTitle.textContent = imageData.title;
    lightboxLink.href = imageData.descUrl;
    lightbox.hidden = false;
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    lightbox.hidden = true;
    document.body.style.overflow = '';
    lightboxImg.src = '';
}

// ========== Event Listeners ==========
searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = searchInput.value.trim();
    if (query.length >= 2) {
        performSearch(query);
    }
});

loadMoreBtn.addEventListener('click', () => {
    if (currentQuery && continueToken) {
        performSearch(currentQuery, true);
    }
});

retryBtn.addEventListener('click', () => {
    if (currentQuery) {
        performSearch(currentQuery);
    }
});

lightboxClose.addEventListener('click', closeLightbox);
lightboxOverlay.addEventListener('click', closeLightbox);

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !lightbox.hidden) {
        closeLightbox();
    }
});

// Focus search input on load
searchInput.focus();
