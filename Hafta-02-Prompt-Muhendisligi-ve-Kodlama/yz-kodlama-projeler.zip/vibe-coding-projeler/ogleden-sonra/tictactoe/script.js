const cells = document.querySelectorAll('.cell');
const statusText = document.getElementById('status');
const resetBtn = document.getElementById('reset-btn');

let board = ['', '', '', '', '', '', '', '', ''];
let currentPlayer = 'A';
let gameActive = true;

const winningConditions = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Satırlar
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Sütunlar
    [0, 4, 8], [2, 4, 6]             // Çaprazlar
];

const initializeGame = () => {
    cells.forEach(cell => cell.addEventListener('click', handleCellClick));
    resetBtn.addEventListener('click', resetGame);
    updateStatusText();
};

const handleCellClick = (e) => {
    const cell = e.target;
    // get data-index instead of assuming cell has custom attribute mapped correctly
    const cellIndex = parseInt(cell.getAttribute('data-index'));

    if (board[cellIndex] !== '' || !gameActive) return;

    updateCell(cell, cellIndex);
    checkWinner();
};

const updateCell = (cell, index) => {
    board[index] = currentPlayer;
    cell.textContent = currentPlayer;
    cell.classList.add(currentPlayer.toLowerCase());
};

const changePlayer = () => {
    currentPlayer = currentPlayer === 'A' ? 'O' : 'A';
    updateStatusText();
};

const updateStatusText = () => {
    statusText.textContent = `Sıra: ${currentPlayer}`;
    if (currentPlayer === 'A') {
        statusText.style.color = 'var(--primary-color)';
        statusText.style.textShadow = '0 2px 10px rgba(255, 71, 87, 0.4)';
    } else {
        statusText.style.color = 'var(--secondary-color)';
        statusText.style.textShadow = '0 2px 10px rgba(46, 213, 115, 0.4)';
    }
};

const checkWinner = () => {
    let roundWon = false;
    let winningCells = [];

    for (let i = 0; i < winningConditions.length; i++) {
        const [a, b, c] = winningConditions[i];
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            roundWon = true;
            winningCells = [a, b, c];
            break;
        }
    }

    if (roundWon) {
        statusText.textContent = `Oyuncu ${currentPlayer} Kazandı! 🎉`;
        statusText.style.color = currentPlayer === 'X' ? 'var(--primary-color)' : 'var(--secondary-color)';
        gameActive = false;

        // Kazanan hücreleri vurgula
        winningCells.forEach(index => {
            cells[index].classList.add('win');
        });
        return;
    }

    if (!board.includes('')) {
        statusText.textContent = 'Berabere! 🤝';
        statusText.style.color = 'var(--text-color)';
        statusText.style.textShadow = 'none';
        gameActive = false;
        return;
    }

    changePlayer();
};

const resetGame = () => {
    board = ['', '', '', '', '', '', '', '', ''];
    currentPlayer = 'A';
    gameActive = true;
    updateStatusText();

    cells.forEach(cell => {
        cell.textContent = '';
        cell.className = 'cell'; // Tüm sınıfları sıfırla, sadece cell kalsın
    });
};

document.addEventListener('DOMContentLoaded', initializeGame);
