/* ===================================================================
   Wikipedia Word Cloud Generator — app.js
   =================================================================== */

// ─── DOM Elements ────────────────────────────────────────────────
const searchForm      = document.getElementById('search-form');
const searchInput     = document.getElementById('search-input');
const searchBtn       = document.getElementById('search-btn');
const statusArea      = document.getElementById('status-area');
const loadingSpinner  = document.getElementById('loading-spinner');
const errorContainer  = document.getElementById('error-message');
const errorText       = document.getElementById('error-text');
const resultSection   = document.getElementById('result-section');
const resultTitle     = document.getElementById('result-title');
const resultLangBadge = document.getElementById('result-lang-badge');
const resultWordCount = document.getElementById('result-word-count');
const canvasWrapper   = document.getElementById('canvas-wrapper');
const canvas          = document.getElementById('wordcloud-canvas');
const themeToggle     = document.getElementById('theme-toggle');

// ─── Stop Words (Turkish + English) ─────────────────────────────
const STOP_WORDS = new Set([
    // Turkish
    'bir','ve','bu','da','de','ile','için','olan','çok','gibi','ama','ancak',
    'daha','en','her','hem','ya','ne','mi','mu','mı','mü','ki','den','dan',
    'ten','tan','dir','dır','dur','dür','tir','tır','tur','tür','ise','iken',
    'olarak','kadar','sonra','önce','üzere','arasında','göre','nasıl','neden',
    'hangi','kendi','buna','şu','ben','sen','biz','siz','onlar','bunlar',
    'şunlar','nin','nın','nun','nün','ın','in','un','ün','ler','lar',
    'leri','ları','deki','daki','den','dan','nda','nde','ndaki','ndeki',
    'olan','olup','olan','etti','etmiş','olmuş','olan','oldu','var','yok',
    'ile','veya','ya','yahut','ise','eğer','çünkü','fakat','lakin','oysa',
    'halbuki','bile','sadece','yalnız','ayrıca','üstelik','dolayı','rağmen',
    'karşı','doğru','beri','itibaren','boyunca','sırasında','esnasında',
    'tarafından','aracılığıyla','vasıtasıyla','hakkında','konusunda',
    'diye','böyle','şöyle','öyle','burada','orada','şurada',
    'ara','o','onu','ona','onun','bu','bunu','buna','bunun',
    'şu','şunu','şuna','şunun','bazı','tüm','bütün','hiç',
    'iç','üst','alt','ön','arka','yan','ilk','son','yeni','eski',
    'büyük','küçük','aynı','başka','diğer','öte','beriki',

    // English
    'the','be','to','of','and','a','in','that','have','i','it','for','not',
    'on','with','he','as','you','do','at','this','but','his','by','from',
    'they','we','say','her','she','or','an','will','my','one','all','would',
    'there','their','what','so','up','out','if','about','who','get','which',
    'go','me','when','make','can','like','time','no','just','him','know',
    'take','people','into','year','your','good','some','could','them','see',
    'other','than','then','now','look','only','come','its','over','think',
    'also','back','after','use','two','how','our','work','first','well',
    'way','even','new','want','because','any','these','give','day','most',
    'us','is','are','was','were','been','being','has','had','did','does',
    'doing','done','got','getting','got','am','may','might','must','shall',
    'should','could','would','need','dare','used','ought','between','each',
    'few','more','many','such','very','own','same','too','quite','rather',
    'still','yet','already','often','never','always','sometimes','usually',
    'however','therefore','thus','hence','meanwhile','moreover','furthermore',
    'although','though','while','whereas','since','until','unless','provided',
    'both','either','neither','nor','whether','through','during','before',
    'above','below','under','again','further','once','here','where','why',
    'much','down','off','been','those','another','around','long','made',
    'called','upon','part','may','also','without','having',
    'within','along','among','against','across','behind','beyond',
    'including','became','became','early','later','known',
    'became','several','found','used','using','based','following',
    'different','form','world','began','second','well','three',
    'often','large','number','set','end','point','small',
    'first','last','great','high','old','right','left','big',
    'little','long','own','same','important','every','next','few',
    'able','many','national','united','states','which','been',
    'still','include','includes','included','become','became','best',
    'through','over','under','between','back','much','off','could',
    'see','systems','system','also','however','such','since',

    // Short / Noise
    'ii','iii','iv','vs','etc','al','ref','pp','ed','vol'
]);

// ─── Color Palettes ─────────────────────────────────────────────
const DARK_PALETTE = [
    '#a78bfa', '#c084fc', '#818cf8', '#f472b6', '#67e8f9',
    '#6ee7b7', '#fbbf24', '#fb923c', '#f87171', '#a3e635',
    '#e879f9', '#38bdf8', '#4ade80', '#facc15', '#fb7185',
];

const LIGHT_PALETTE = [
    '#7c3aed', '#9333ea', '#4f46e5', '#db2777', '#0891b2',
    '#059669', '#d97706', '#ea580c', '#dc2626', '#65a30d',
    '#c026d3', '#0284c7', '#16a34a', '#ca8a04', '#e11d48',
];

// ─── Theme Toggle ───────────────────────────────────────────────
function getCurrentTheme() {
    return document.documentElement.getAttribute('data-theme') || 'dark';
}

function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('wiki-wc-theme', theme);
}

themeToggle.addEventListener('click', () => {
    const current = getCurrentTheme();
    setTheme(current === 'dark' ? 'light' : 'dark');

    // Re-render word cloud with new palette if data exists
    if (lastWordList && lastWordList.length > 0) {
        renderWordCloud(lastWordList);
    }
});

// Restore saved theme
const savedTheme = localStorage.getItem('wiki-wc-theme');
if (savedTheme) setTheme(savedTheme);

// ─── Globals ────────────────────────────────────────────────────
let lastWordList = null;

// ─── Wikipedia API ──────────────────────────────────────────────

/**
 * Try to fetch a Wikipedia page extract.
 * Tries Turkish first, then falls back to English.
 * Returns { title, extract, lang } or throws.
 */
async function fetchWikipediaContent(query) {
    const langs = ['tr', 'en'];

    for (const lang of langs) {
        const searchUrl = `https://${lang}.wikipedia.org/w/api.php?` + new URLSearchParams({
            action: 'query',
            list: 'search',
            srsearch: query,
            srlimit: '1',
            format: 'json',
            origin: '*',
        });

        const searchRes = await fetch(searchUrl);
        const searchData = await searchRes.json();

        if (!searchData.query?.search?.length) continue;

        const pageTitle = searchData.query.search[0].title;

        const contentUrl = `https://${lang}.wikipedia.org/w/api.php?` + new URLSearchParams({
            action: 'query',
            titles: pageTitle,
            prop: 'extracts',
            explaintext: '1',
            exlimit: '1',
            format: 'json',
            origin: '*',
        });

        const contentRes = await fetch(contentUrl);
        const contentData = await contentRes.json();
        const pages = contentData.query?.pages;
        if (!pages) continue;

        const page = Object.values(pages)[0];
        if (!page || page.missing !== undefined || !page.extract) continue;

        return {
            title: page.title,
            extract: page.extract,
            lang: lang === 'tr' ? 'Türkçe' : 'English',
        };
    }

    throw new Error('Bu konuyla ilgili bir Wikipedia makalesi bulunamadı. Lütfen farklı bir arama terimi deneyin.');
}

// ─── Text Processing ────────────────────────────────────────────

function processText(text) {
    // Lowercase & strip non-letter characters (keep Turkish chars)
    const cleaned = text
        .toLowerCase()
        .replace(/[^a-zA-ZçÇğĞıİöÖşŞüÜâÂîÎûÛ\s]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

    const words = cleaned.split(' ');
    const freq = {};

    for (const w of words) {
        if (w.length < 3) continue;               // skip very short
        if (STOP_WORDS.has(w)) continue;           // skip stop words
        if (/^\d+$/.test(w)) continue;             // skip pure numbers
        freq[w] = (freq[w] || 0) + 1;
    }

    // Sort by frequency, take top N
    const sorted = Object.entries(freq)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 120);

    return sorted; // [[word, count], ...]
}

// ─── Word Cloud Rendering ───────────────────────────────────────

function renderWordCloud(wordList) {
    lastWordList = wordList;

    const wrapperWidth  = canvasWrapper.clientWidth - 32; // minus padding
    const wrapperHeight = Math.max(420, Math.min(wrapperWidth * 0.6, 560));

    canvas.width  = wrapperWidth  * (window.devicePixelRatio || 1);
    canvas.height = wrapperHeight * (window.devicePixelRatio || 1);
    canvas.style.width  = wrapperWidth + 'px';
    canvas.style.height = wrapperHeight + 'px';

    const maxCount = wordList[0]?.[1] || 1;
    const palette = getCurrentTheme() === 'dark' ? DARK_PALETTE : LIGHT_PALETTE;

    // Determine base weighted font size
    const baseFontSize = Math.max(12, Math.min(wrapperWidth / 18, 48));

    const list = wordList.map(([word, count]) => {
        const weight = (count / maxCount);
        const size = Math.max(10, Math.round(baseFontSize * (0.3 + weight * 0.7)));
        return [word, size];
    });

    // Clear canvas
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    WordCloud(canvas, {
        list: list,
        gridSize: Math.round(8 * (window.devicePixelRatio || 1)),
        weightFactor: window.devicePixelRatio || 1,
        fontFamily: 'Inter, sans-serif',
        fontWeight: 600,
        color: () => palette[Math.floor(Math.random() * palette.length)],
        rotateRatio: 0.3,
        rotationSteps: 2,
        backgroundColor: 'transparent',
        drawOutOfBound: false,
        shrinkToFit: true,
        shuffle: true,
        wait: 20,
    });
}

// ─── UI Helpers ─────────────────────────────────────────────────

function showLoading() {
    statusArea.classList.remove('hidden');
    loadingSpinner.classList.remove('hidden');
    errorContainer.classList.add('hidden');
    resultSection.classList.add('hidden');
    searchBtn.disabled = true;
}

function hideLoading() {
    loadingSpinner.classList.add('hidden');
    searchBtn.disabled = false;
}

function showError(message) {
    statusArea.classList.remove('hidden');
    errorContainer.classList.remove('hidden');
    errorText.textContent = message;
    resultSection.classList.add('hidden');
    searchBtn.disabled = false;
}

function showResult(title, lang, wordCount) {
    statusArea.classList.add('hidden');
    resultSection.classList.remove('hidden');
    resultTitle.textContent = `"${title}" — Kelime Bulutu`;
    resultLangBadge.textContent = lang;
    resultWordCount.textContent = `${wordCount} kelime`;
}

// ─── Event Handlers ─────────────────────────────────────────────

async function handleSearch(query) {
    if (!query.trim()) return;

    showLoading();

    try {
        const data = await fetchWikipediaContent(query.trim());
        const wordList = processText(data.extract);

        if (wordList.length < 5) {
            throw new Error('Makale yeterince kelime içermiyor. Farklı bir konu deneyin.');
        }

        hideLoading();
        showResult(data.title, data.lang, wordList.length);

        // Small delay so DOM settles before measuring canvas wrapper
        requestAnimationFrame(() => {
            renderWordCloud(wordList);
        });
    } catch (err) {
        hideLoading();
        showError(err.message || 'Beklenmeyen bir hata oluştu.');
    }
}

searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    handleSearch(searchInput.value);
});

// Hint chips
document.querySelectorAll('.hint-chip').forEach((chip) => {
    chip.addEventListener('click', () => {
        const topic = chip.getAttribute('data-topic');
        searchInput.value = topic;
        handleSearch(topic);
    });
});

// Responsive re-render on window resize
let resizeTimer;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
        if (lastWordList && lastWordList.length > 0) {
            renderWordCloud(lastWordList);
        }
    }, 250);
});
