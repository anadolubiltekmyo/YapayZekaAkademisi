// ── Stop Words ───────────────────────────────────────────────
const STOP_WORDS = new Set([
  'the','be','to','of','and','a','in','that','have','i','it','for','not','on',
  'with','he','as','you','do','at','this','but','his','by','from','they','we',
  'say','her','she','or','an','will','my','one','all','would','there','their',
  'what','so','up','out','if','about','who','get','which','go','me','when',
  'make','can','like','time','no','just','him','know','take','people','into',
  'year','your','good','some','could','them','see','other','than','then','now',
  'look','only','come','its','over','think','also','back','after','use','two',
  'how','our','work','first','well','way','even','new','want','because','any',
  'these','give','day','most','us','was','were','been','has','had','are','is',
  'did','does','being','having','each','where','may','more','much','very',
  'such','many','own','part','still','should','between','before','during',
  'while','those','both','through','under','same','another','found','since',
  'used','called','often','made','known','became','however','until','including',
  'among','several','within','later','around','without','early','became','began',
  'against','over','along','although','among','became','become','began','begin',
  'being','between','both','came','come','could','does','done','during','each',
  'either','every','find','found','from','gave','give','goes','gone','grew',
  'grow','grown','half','have','here','high','hold','home','house','into',
  'just','keep','kept','know','known','large','last','late','lead','left',
  'less','life','line','live','long','look','made','main','make','many','mark',
  'mean','might','mind','miss','more','most','move','much','must','name','near',
  'need','next','note','number','once','only','open','order','over','page',
  'part','past','play','point','post','pull','push','read','real','rest','rise',
  'role','room','rule','said','same','seem','self','send','serve','set','show',
  'side','sign','site','small','some','sort','star','start','state','still',
  'stop','such','sure','take','talk','tell','term','text','than','that','them',
  'then','they','this','thus','time','told','took','true','turn','type','upon',
  'very','view','want','well','went','were','what','when','wide','will','with',
  'word','work','year','also','back','call','case','change','city','close',
  'come','date','down','even','fact','feel','form','full','game','good','great',
  'group','hand','help','here','high','hold','home','idea','keep','kind',
  'large','last','late','left','level','life','like','line','list','live',
  'long','look','lose','make','mark','mean','meet','move','much','name','need',
  'never','next','night','number','offer','often','open','order','other',
  'own','part','pass','place','plan','play','point','power','put','quite',
  'rather','really','right','room','run','same','school','seem','serve',
  'shall','short','show','side','since','small','some','stand','start',
  'state','still','story','study','such','system','take','tell','tend',
  'thing','think','three','through','too','turn','under','upon','use','very',
  'want','water','way','week','well','while','white','whole','whose','will',
  'without','word','work','world','would','write','years','young',
  'ref','may','one','two','first','new','also','see','references','external',
  'links','isbn','retrieved','january','february','march','april','june',
  'july','august','september','october','november','december','pp','vol',
  'http','https','www','com','org','edu'
]);

// ── Color Palettes ───────────────────────────────────────────
const COLOR_PALETTES = {
  neon: [
    '#6366f1', '#818cf8', '#a78bfa', '#c084fc',
    '#ec4899', '#f472b6', '#fb7185',
    '#06b6d4', '#22d3ee', '#2dd4bf',
    '#34d399', '#4ade80',
    '#facc15', '#fb923c', '#f87171',
  ],
  ocean: [
    '#0ea5e9', '#38bdf8', '#7dd3fc',
    '#06b6d4', '#22d3ee', '#67e8f9',
    '#3b82f6', '#60a5fa', '#93c5fd',
    '#2dd4bf', '#5eead4',
    '#818cf8', '#a5b4fc',
  ],
  sunset: [
    '#f97316', '#fb923c', '#fdba74',
    '#ef4444', '#f87171', '#fca5a5',
    '#eab308', '#facc15', '#fde047',
    '#f472b6', '#ec4899',
    '#e879f9', '#d946ef',
  ],
  forest: [
    '#22c55e', '#4ade80', '#86efac',
    '#16a34a', '#15803d',
    '#84cc16', '#a3e635', '#bef264',
    '#14b8a6', '#2dd4bf',
    '#059669', '#34d399',
    '#65a30d', '#a3e635',
  ],
  candy: [
    '#f472b6', '#fb7185', '#fda4af',
    '#c084fc', '#d8b4fe', '#e9d5ff',
    '#f0abfc', '#e879f9',
    '#93c5fd', '#7dd3fc',
    '#fda4af', '#fecdd3',
    '#fdba74', '#fcd34d',
  ],
  mono: [
    '#e2e8f0', '#cbd5e1', '#94a3b8',
    '#64748b', '#475569', '#334155',
    '#f1f5f9', '#d1d5db', '#9ca3af',
    '#6b7280', '#4b5563',
    '#f8fafc', '#e5e7eb',
  ],
};

// ── Shape Mask Functions (returns true if point is inside shape) ──
function createShapeMask(shape, width, height) {
  const cx = width / 2;
  const cy = height / 2;

  switch (shape) {
    case 'circle': {
      const r = Math.min(cx, cy) * 0.9;
      return (x, y) => {
        const dx = x - cx, dy = y - cy;
        return (dx * dx + dy * dy) <= r * r;
      };
    }
    case 'diamond': {
      const rx = cx * 0.85, ry = cy * 0.85;
      return (x, y) => {
        return (Math.abs(x - cx) / rx + Math.abs(y - cy) / ry) <= 1;
      };
    }
    case 'triangle': {
      return (x, y) => {
        const normX = (x - cx) / (cx * 0.9);
        const normY = (y - cy) / (cy * 0.9);
        const row = (normY + 1) / 2;
        return normY >= -0.9 && normY <= 0.9 && Math.abs(normX) <= row;
      };
    }
    case 'star': {
      return (x, y) => {
        const dx = x - cx, dy = y - cy;
        const angle = Math.atan2(dy, dx);
        const dist = Math.sqrt(dx * dx + dy * dy);
        const maxR = Math.min(cx, cy) * 0.9;
        const spikes = 5;
        const a = angle + Math.PI / 2;
        const r = maxR * (0.5 + 0.5 * Math.cos(spikes * a));
        return dist <= r;
      };
    }
    case 'heart': {
      return (x, y) => {
        const scale = Math.min(cx, cy) * 0.05;
        const nx = (x - cx) / scale;
        const ny = -(y - cy) / scale - 5;
        const eq = (nx * nx + ny * ny - 1);
        return (eq * eq * eq - nx * nx * ny * ny * ny) <= 0;
      };
    }
    default:
      return null;
  }
}

// ── Current Options State ────────────────────────────────────
let currentOptions = {
  shape: 'classic',
  colorTheme: 'neon',
  font: 'Inter',
  maxWords: 150,
};

// Store the last fetched data for re-renders
let lastPageData = null;

// ── DOM References ───────────────────────────────────────────
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const suggestionsEl = document.getElementById('suggestions');
const loadingEl = document.getElementById('loading');
const resultArea = document.getElementById('resultArea');
const pageTitleEl = document.getElementById('pageTitle');
const wikiLinkEl = document.getElementById('wikiLink');
const wordCloudEl = document.getElementById('wordCloud');
const statsEl = document.getElementById('stats');
const optionsToggle = document.getElementById('optionsToggle');
const optionsBody = document.getElementById('optionsBody');
const maxWordsSlider = document.getElementById('maxWordsSlider');
const maxWordsValue = document.getElementById('maxWordsValue');

let debounceTimer = null;

// ── Options Panel Toggle ─────────────────────────────────────
optionsToggle.addEventListener('click', () => {
  optionsToggle.classList.toggle('open');
  optionsBody.classList.toggle('open');
});

// ── Chip Selection (Shape, Color, Font) ──────────────────────
function setupChips(containerId, optionKey) {
  const container = document.getElementById(containerId);
  container.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      container.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      currentOptions[optionKey] = chip.dataset.value;
      reRenderIfNeeded();
    });
  });
}

setupChips('shapeChips', 'shape');
setupChips('colorChips', 'colorTheme');
setupChips('fontChips', 'font');

// ── Max Words Slider ─────────────────────────────────────────
maxWordsSlider.addEventListener('input', () => {
  maxWordsValue.textContent = maxWordsSlider.value;
  currentOptions.maxWords = parseInt(maxWordsSlider.value);
});

maxWordsSlider.addEventListener('change', () => {
  currentOptions.maxWords = parseInt(maxWordsSlider.value);
  reRenderIfNeeded();
});

// ── Re-render word cloud when options change ─────────────────
function reRenderIfNeeded() {
  if (!lastPageData) return;
  const words = extractWords(lastPageData.text);
  if (words.length === 0) return;
  displayResult(lastPageData.title, words, lastPageData.text);
}

// ── Search Event Listeners ───────────────────────────────────
searchInput.addEventListener('input', () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    const q = searchInput.value.trim();
    if (q.length >= 2) {
      fetchSuggestions(q);
    } else {
      hideSuggestions();
    }
  }, 350);
});

searchInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    hideSuggestions();
    const q = searchInput.value.trim();
    if (q) selectPage(q);
  }
});

searchBtn.addEventListener('click', () => {
  hideSuggestions();
  const q = searchInput.value.trim();
  if (q) selectPage(q);
});

document.addEventListener('click', (e) => {
  if (!suggestionsEl.contains(e.target) && e.target !== searchInput) {
    hideSuggestions();
  }
});

// ── Fetch Suggestions ────────────────────────────────────────
async function fetchSuggestions(query) {
  try {
    const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    const data = await res.json();

    if (data.results && data.results.length > 0) {
      showSuggestions(data.results);
    } else {
      hideSuggestions();
    }
  } catch (err) {
    console.error('Suggestion error:', err);
  }
}

function showSuggestions(results) {
  suggestionsEl.innerHTML = results.map(r => `
    <div class="suggestion-item" data-title="${escapeHtml(r.title)}">
      <div class="title">${escapeHtml(r.title)}</div>
      <div class="snippet">${escapeHtml(r.snippet)}</div>
    </div>
  `).join('');

  suggestionsEl.classList.remove('hidden');

  suggestionsEl.querySelectorAll('.suggestion-item').forEach(item => {
    item.addEventListener('click', () => {
      const title = item.dataset.title;
      searchInput.value = title;
      hideSuggestions();
      selectPage(title);
    });
  });
}

function hideSuggestions() {
  suggestionsEl.classList.add('hidden');
}

// ── Select and Load Page ─────────────────────────────────────
async function selectPage(title) {
  showLoading();
  hideResult();

  try {
    const res = await fetch(`/api/page?title=${encodeURIComponent(title)}`);
    const data = await res.json();

    if (data.error || !data.text) {
      hideLoading();
      alert('Could not fetch the Wikipedia page. Please try a different search term.');
      return;
    }

    lastPageData = data;
    const words = extractWords(data.text);
    hideLoading();

    if (words.length === 0) {
      alert('Not enough content found to generate a word cloud.');
      return;
    }

    displayResult(data.title, words, data.text);
  } catch (err) {
    console.error('Page load error:', err);
    hideLoading();
    alert('Something went wrong. Please try again.');
  }
}

// ── Text Processing ──────────────────────────────────────────
function extractWords(text) {
  const cleaned = text
    .toLowerCase()
    .replace(/[^a-zA-ZÀ-ÿçğışöüÇĞİŞÖÜ\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const freq = {};
  cleaned.split(' ').forEach(word => {
    if (word.length < 3) return;
    if (STOP_WORDS.has(word)) return;
    if (/^\d+$/.test(word)) return;
    freq[word] = (freq[word] || 0) + 1;
  });

  const sorted = Object.entries(freq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, currentOptions.maxWords);

  if (sorted.length === 0) return [];

  const maxFreq = sorted[0][1];

  return sorted.map(([text, count]) => ({
    text,
    size: Math.max(12, Math.round((count / maxFreq) * 72)),
    count
  }));
}

// ── Render Word Cloud ────────────────────────────────────────
function displayResult(title, words, fullText) {
  pageTitleEl.textContent = title;
  wikiLinkEl.href = `https://en.wikipedia.org/wiki/${encodeURIComponent(title)}`;

  const totalWords = fullText.split(/\s+/).length;
  const uniqueWords = words.length;
  const topWord = words[0];

  statsEl.innerHTML = `
    <div class="stat-card">
      <div class="value">${totalWords.toLocaleString()}</div>
      <div class="label">Total Words</div>
    </div>
    <div class="stat-card">
      <div class="value">${uniqueWords}</div>
      <div class="label">Unique Keywords</div>
    </div>
    <div class="stat-card">
      <div class="value">"${topWord.text}"</div>
      <div class="label">Most Frequent (${topWord.count}×)</div>
    </div>
  `;

  renderWordCloud(words);
  resultArea.classList.remove('hidden');
}

function renderWordCloud(words) {
  // Remove old tooltips
  d3.selectAll('.wc-tooltip').remove();
  wordCloudEl.innerHTML = '';

  const container = wordCloudEl;
  const width = container.clientWidth || 800;
  const height = 500;

  const colors = COLOR_PALETTES[currentOptions.colorTheme] || COLOR_PALETTES.neon;
  const font = currentOptions.font;
  const shape = currentOptions.shape;

  const maskFn = createShapeMask(shape, width, height);

  const layout = d3.layout.cloud()
    .size([width, height])
    .words(words.map(w => ({ ...w })))
    .padding(shape === 'classic' ? 4 : 3)
    .rotate(() => {
      if (shape === 'circle' || shape === 'heart') {
        return (~~(Math.random() * 2)) * 90;
      }
      return (~~(Math.random() * 3) - 1) * 30;
    })
    .font(font)
    .fontSize(d => d.size)
    .spiral(shape === 'classic' ? 'archimedean' : 'rectangular')
    .on('end', draw);

  layout.start();

  function draw(drawnWords) {
    // If we have a shape mask, filter words that fall outside
    let finalWords = drawnWords;
    if (maskFn) {
      finalWords = drawnWords.filter(d => {
        const px = d.x + width / 2;
        const py = d.y + height / 2;
        return maskFn(px, py);
      });
    }

    const svg = d3.select('#wordCloud')
      .append('svg')
      .attr('width', width)
      .attr('height', height)
      .attr('viewBox', `0 0 ${width} ${height}`)
      .style('max-width', '100%');

    const g = svg.append('g')
      .attr('transform', `translate(${width / 2},${height / 2})`);

    // Draw shape outline hint (faint)
    if (shape !== 'classic') {
      drawShapeOutline(g, shape, width, height);
    }

    const tooltip = d3.select('body').append('div')
      .attr('class', 'wc-tooltip')
      .style('position', 'absolute')
      .style('background', '#1e1e3a')
      .style('color', '#e2e8f0')
      .style('padding', '8px 14px')
      .style('border-radius', '8px')
      .style('font-size', '13px')
      .style('font-family', 'Inter, sans-serif')
      .style('pointer-events', 'none')
      .style('opacity', 0)
      .style('border', '1px solid #3a3a5a')
      .style('box-shadow', '0 4px 12px rgba(0,0,0,0.4)')
      .style('z-index', 1000)
      .style('transition', 'opacity 0.15s');

    g.selectAll('text')
      .data(finalWords)
      .enter()
      .append('text')
      .style('font-size', d => `${d.size}px`)
      .style('font-family', font)
      .style('font-weight', d => d.size > 40 ? '700' : d.size > 25 ? '600' : '400')
      .style('fill', (d, i) => colors[i % colors.length])
      .style('cursor', 'pointer')
      .style('transition', 'opacity 0.2s, transform 0.2s')
      .attr('text-anchor', 'middle')
      .attr('transform', d => `translate(${d.x},${d.y})rotate(${d.rotate})`)
      .text(d => d.text)
      .style('opacity', 0)
      .on('mouseover', function (event, d) {
        d3.select(this).style('opacity', 0.7);
        tooltip
          .html(`<strong>${d.text}</strong> — ${d.count} occurrences`)
          .style('left', (event.pageX + 12) + 'px')
          .style('top', (event.pageY - 10) + 'px')
          .style('opacity', 1);
      })
      .on('mousemove', function (event) {
        tooltip
          .style('left', (event.pageX + 12) + 'px')
          .style('top', (event.pageY - 10) + 'px');
      })
      .on('mouseout', function () {
        d3.select(this).style('opacity', 1);
        tooltip.style('opacity', 0);
      })
      .transition()
      .duration(600)
      .delay((d, i) => i * 6)
      .style('opacity', 1);
  }
}

// ── Draw faint shape outline ─────────────────────────────────
function drawShapeOutline(g, shape, width, height) {
  const hw = width / 2 * 0.9;
  const hh = height / 2 * 0.9;

  const outline = g.append('g').attr('class', 'shape-outline');
  const strokeStyle = 'rgba(99,102,241,0.08)';

  switch (shape) {
    case 'circle':
      outline.append('circle')
        .attr('cx', 0).attr('cy', 0)
        .attr('r', Math.min(hw, hh))
        .attr('fill', 'none')
        .attr('stroke', strokeStyle)
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', '6,4');
      break;

    case 'diamond':
      outline.append('polygon')
        .attr('points', `0,${-hh} ${hw},0 0,${hh} ${-hw},0`)
        .attr('fill', 'none')
        .attr('stroke', strokeStyle)
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', '6,4');
      break;

    case 'triangle':
      outline.append('polygon')
        .attr('points', `0,${-hh} ${hw},${hh} ${-hw},${hh}`)
        .attr('fill', 'none')
        .attr('stroke', strokeStyle)
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', '6,4');
      break;

    case 'star': {
      const spikes = 5;
      const outerR = Math.min(hw, hh);
      const innerR = outerR * 0.4;
      let points = '';
      for (let i = 0; i < spikes * 2; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const angle = (Math.PI / spikes) * i - Math.PI / 2;
        points += `${r * Math.cos(angle)},${r * Math.sin(angle)} `;
      }
      outline.append('polygon')
        .attr('points', points.trim())
        .attr('fill', 'none')
        .attr('stroke', strokeStyle)
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', '6,4');
      break;
    }

    case 'heart': {
      const scale = Math.min(hw, hh) * 0.05;
      let path = '';
      for (let i = 0; i <= 360; i += 1) {
        const t = (i * Math.PI) / 180;
        const x = 16 * Math.pow(Math.sin(t), 3);
        const y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
        const px = x * scale;
        const py = y * scale;
        path += (i === 0 ? 'M' : 'L') + `${px},${py}`;
      }
      path += 'Z';
      outline.append('path')
        .attr('d', path)
        .attr('fill', 'none')
        .attr('stroke', strokeStyle)
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', '6,4');
      break;
    }
  }
}

// ── Helpers ──────────────────────────────────────────────────
function showLoading() { loadingEl.classList.remove('hidden'); }
function hideLoading() { loadingEl.classList.add('hidden'); }
function hideResult() { resultArea.classList.add('hidden'); }

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
