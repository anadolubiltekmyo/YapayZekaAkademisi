const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Wikipedia API proxy endpoint
app.get('/api/search', async (req, res) => {
  const query = req.query.q;
  if (!query) {
    return res.status(400).json({ error: 'Query parameter "q" is required' });
  }

  try {
    // Search for the Wikipedia page
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&srlimit=5`;
    const searchRes = await fetch(searchUrl);
    const searchData = await searchRes.json();

    if (!searchData.query || !searchData.query.search || searchData.query.search.length === 0) {
      return res.json({ error: 'No Wikipedia page found', results: [] });
    }

    const results = searchData.query.search.map(item => ({
      title: item.title,
      pageid: item.pageid,
      snippet: item.snippet.replace(/<[^>]*>/g, '')
    }));

    res.json({ results });
  } catch (err) {
    console.error('Search error:', err);
    res.status(500).json({ error: 'Failed to search Wikipedia' });
  }
});

// Get page content
app.get('/api/page', async (req, res) => {
  const title = req.query.title;
  if (!title) {
    return res.status(400).json({ error: 'Query parameter "title" is required' });
  }

  try {
    const pageUrl = `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(title)}&prop=extracts&explaintext=true&format=json`;
    const pageRes = await fetch(pageUrl);
    const pageData = await pageRes.json();

    const pages = pageData.query.pages;
    const pageId = Object.keys(pages)[0];

    if (pageId === '-1') {
      return res.json({ error: 'Page not found', text: '' });
    }

    const text = pages[pageId].extract || '';
    const pageTitle = pages[pageId].title || title;

    res.json({ title: pageTitle, text });
  } catch (err) {
    console.error('Page fetch error:', err);
    res.status(500).json({ error: 'Failed to fetch Wikipedia page' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Wiki Word Cloud server running at http://localhost:${PORT}`);
});
