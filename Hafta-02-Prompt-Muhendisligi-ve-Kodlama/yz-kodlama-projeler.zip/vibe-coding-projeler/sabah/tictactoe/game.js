// ============================================
// GAME STATE
// ============================================
const state = {
    board: Array(9).fill(null),
    currentPlayer: 'X',
    gameActive: true,
    mode: null, // 'pvp', 'ai-easy', 'ai-hard'
    scores: { X: 0, O: 0, draw: 0 },
    aiThinking: false,
};

const WIN_COMBOS = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Satırlar
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Sütunlar
    [0, 4, 8], [2, 4, 6]             // Çaprazlar
];

// ============================================
// DOM ELEMENTS
// ============================================
const modeSelect = document.getElementById('mode-select');
const gameArea = document.getElementById('game-area');
const boardEl = document.getElementById('board');
const cells = document.querySelectorAll('.cell');
const turnText = document.getElementById('turn-text');
const scoreX = document.getElementById('score-x');
const scoreDraw = document.getElementById('score-draw');
const scoreO = document.getElementById('score-o');
const resultModal = document.getElementById('result-modal');
const resultIcon = document.getElementById('result-icon');
const resultText = document.getElementById('result-text');
const resultSub = document.getElementById('result-sub');

// ============================================
// MODE SELECTION
// ============================================
function selectMode(mode) {
    state.mode = mode;
    modeSelect.classList.add('hidden');
    gameArea.classList.remove('hidden');
    resetBoard();
}

function goBack() {
    gameArea.classList.add('hidden');
    modeSelect.classList.remove('hidden');
    state.mode = null;
    state.scores = { X: 0, O: 0, draw: 0 };
    updateScoreboard();
}

// ============================================
// GAME LOGIC
// ============================================
function handleCellClick(index) {
    if (!state.gameActive || state.board[index] || state.aiThinking) return;

    makeMove(index, state.currentPlayer);

    if (!state.gameActive) return;

    // AI hamlesi
    if (state.mode !== 'pvp') {
        state.aiThinking = true;
        updateTurnText();
        setTimeout(() => {
            if (!state.gameActive) {
                state.aiThinking = false;
                return;
            }
            const aiMove = state.mode === 'ai-hard' ? getBestMove() : getEasyMove();
            if (aiMove !== -1) {
                makeMove(aiMove, 'O');
            }
            state.aiThinking = false;
            if (state.gameActive) updateTurnText();
        }, 400);
    }
}

function makeMove(index, player) {
    state.board[index] = player;
    const cell = cells[index];
    cell.textContent = player;
    cell.classList.add(player.toLowerCase(), 'taken');

    // Hücre yerleştirme ses efekti (opsiyonel titreşim)
    if (navigator.vibrate) navigator.vibrate(10);

    const winCombo = checkWin(player);
    if (winCombo) {
        endGame(player, winCombo);
        return;
    }

    if (state.board.every(cell => cell !== null)) {
        endGame(null);
        return;
    }

    state.currentPlayer = state.currentPlayer === 'X' ? 'O' : 'X';
    updateTurnText();
}

function checkWin(player) {
    for (const combo of WIN_COMBOS) {
        if (combo.every(i => state.board[i] === player)) {
            return combo;
        }
    }
    return null;
}

function endGame(winner, winCombo = null) {
    state.gameActive = false;

    if (winCombo) {
        // Kazanan hücreleri vurgula
        winCombo.forEach(i => cells[i].classList.add('win-cell'));

        state.scores[winner]++;
        updateScoreboard();

        // Sonuç modalı
        setTimeout(() => {
            if (winner === 'X') {
                resultIcon.textContent = '🎉';
                resultText.textContent = 'X Kazandı!';
                resultText.style.color = 'var(--color-x-light)';
                resultSub.textContent = state.mode !== 'pvp' ? 'Tebrikler, bilgisayarı yendin!' : 'Harika bir hamleydi!';
            } else {
                resultIcon.textContent = state.mode !== 'pvp' ? '🤖' : '🎉';
                resultText.textContent = 'O Kazandı!';
                resultText.style.color = 'var(--color-o-light)';
                resultSub.textContent = state.mode !== 'pvp' ? 'Bilgisayar bu sefer kazandı!' : 'Mükemmel oyun!';
            }
            showModal();
        }, 600);
    } else {
        state.scores.draw++;
        updateScoreboard();

        setTimeout(() => {
            resultIcon.textContent = '🤝';
            resultText.textContent = 'Berabere!';
            resultText.style.color = 'var(--color-draw)';
            resultSub.textContent = 'Harika bir mücadele oldu!';
            showModal();
        }, 400);
    }
}

// ============================================
// AI - EASY (Random)
// ============================================
function getEasyMove() {
    const emptyCells = state.board
        .map((val, idx) => val === null ? idx : -1)
        .filter(idx => idx !== -1);

    if (emptyCells.length === 0) return -1;

    // %50 ihtimalle akıllı hamle yap, %50 rastgele
    if (Math.random() < 0.5) {
        // Kazanabiliyorsa kazan
        for (const i of emptyCells) {
            state.board[i] = 'O';
            if (checkWin('O')) { state.board[i] = null; return i; }
            state.board[i] = null;
        }
        // Rakibi engelle
        for (const i of emptyCells) {
            state.board[i] = 'X';
            if (checkWin('X')) { state.board[i] = null; return i; }
            state.board[i] = null;
        }
    }

    return emptyCells[Math.floor(Math.random() * emptyCells.length)];
}

// ============================================
// AI - HARD (Minimax)
// ============================================
function getBestMove() {
    let bestScore = -Infinity;
    let bestMove = -1;

    for (let i = 0; i < 9; i++) {
        if (state.board[i] === null) {
            state.board[i] = 'O';
            const score = minimax(state.board, 0, false);
            state.board[i] = null;
            if (score > bestScore) {
                bestScore = score;
                bestMove = i;
            }
        }
    }

    return bestMove;
}

function minimax(board, depth, isMaximizing) {
    // Terminal durumlar
    if (checkWin('O')) return 10 - depth;
    if (checkWin('X')) return depth - 10;
    if (board.every(cell => cell !== null)) return 0;

    if (isMaximizing) {
        let bestScore = -Infinity;
        for (let i = 0; i < 9; i++) {
            if (board[i] === null) {
                board[i] = 'O';
                bestScore = Math.max(bestScore, minimax(board, depth + 1, false));
                board[i] = null;
            }
        }
        return bestScore;
    } else {
        let bestScore = Infinity;
        for (let i = 0; i < 9; i++) {
            if (board[i] === null) {
                board[i] = 'X';
                bestScore = Math.min(bestScore, minimax(board, depth + 1, true));
                board[i] = null;
            }
        }
        return bestScore;
    }
}

// ============================================
// UI UPDATES
// ============================================
function updateTurnText() {
    if (state.aiThinking) {
        turnText.textContent = 'Bilgisayar düşünüyor...';
        turnText.className = 'turn-text turn-o';
        return;
    }
    const isX = state.currentPlayer === 'X';
    turnText.textContent = isX ? "X'in sırası" : "O'nun sırası";
    turnText.className = `turn-text ${isX ? 'turn-x' : 'turn-o'}`;
}

function updateScoreboard() {
    scoreX.textContent = state.scores.X;
    scoreDraw.textContent = state.scores.draw;
    scoreO.textContent = state.scores.O;

    // Skor animasyonu
    [scoreX, scoreDraw, scoreO].forEach(el => {
        el.style.transform = 'scale(1.3)';
        setTimeout(() => el.style.transform = 'scale(1)', 200);
    });
}

function showModal() {
    resultModal.classList.remove('hidden');
}

function hideModal() {
    resultModal.classList.add('hidden');
}

// ============================================
// GAME CONTROLS
// ============================================
function restartGame() {
    hideModal();
    resetBoard();
}

function resetBoard() {
    state.board = Array(9).fill(null);
    state.currentPlayer = 'X';
    state.gameActive = true;
    state.aiThinking = false;

    cells.forEach(cell => {
        cell.textContent = '';
        cell.className = 'cell';
    });

    updateTurnText();
}

// ============================================
// KEYBOARD SUPPORT
// ============================================
document.addEventListener('keydown', (e) => {
    // Numpad veya sayı tuşlarıyla oynama (1-9)
    const key = parseInt(e.key);
    if (key >= 1 && key <= 9 && state.gameActive && !state.aiThinking) {
        // Numpad düzeni: 7=0, 8=1, 9=2, 4=3, 5=4, 6=5, 1=6, 2=7, 3=8
        const mapping = [null, 6, 7, 8, 3, 4, 5, 0, 1, 2];
        handleCellClick(mapping[key]);
    }

    // Escape ile modal kapat
    if (e.key === 'Escape') {
        hideModal();
    }

    // R ile restart
    if (e.key === 'r' || e.key === 'R') {
        restartGame();
    }
});

// Modal dışına tıklayınca kapat
resultModal.addEventListener('click', (e) => {
    if (e.target === resultModal) {
        hideModal();
    }
});
