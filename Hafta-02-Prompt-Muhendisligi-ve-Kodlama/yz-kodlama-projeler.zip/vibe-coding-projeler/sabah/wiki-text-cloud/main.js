const topicInput = document.getElementById('topicInput');
const generateBtn = document.getElementById('generateBtn');
const canvas = document.getElementById('wordCloudCanvas');
const loadingDiv = document.getElementById('loading');
const errorBox = document.getElementById('errorBox');
const canvasContainer = document.querySelector('.canvas-container');

// Turkish stop words list
const stopWords = new Set([
  "ve", "ise", "ile", "bir", "bu", "şu", "o", "için", "gibi", "kadar", "olan", "olarak", "da", "de", "ki", 
  "çok", "daha", "en", "veya", "ya", "ama", "fakat", "lakin", "ancak", "çünkü", "göre", "böyle", "şöyle", 
  "öyle", "tarafından", "sonra", "önce", "kendi", "bazı", "tüm", "her", "hiç", "ne", "hangi", 
  "kim", "nasıl", "neden", "niçin", "var", "yok", "değil", "arasında", "içinde", "üzerinde",
  "nın", "nin", "nun", "nün", "dır", "dir", "dur", "dür", "tır", "tir", "tur", "tür", "dan", "den", "tan", "ten",
  "olduğunu", "olduğu", "olması", "olmak", "vardır", "yoktur", "ilgili", "özellikle", "örneğin", "bunlar", "onlar", "diğer", "kabul", "edilir"
]);

function showError(msg) {
  errorBox.textContent = msg;
  errorBox.classList.remove('hidden');
}

function hideError() {
  errorBox.classList.add('hidden');
  errorBox.textContent = '';
}

async function fetchWikipediaExtract(topic) {
  // We use extract instead of summary, meaning it brings intro.
  // We can fetch more by not using exintro=true, but exintro is faster. Let's fetch without exintro to get full text.
  const url = `https://tr.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&explaintext=true&titles=${encodeURIComponent(topic)}&origin=*`;
  
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error('Wikipedia ile iletişim kurulamadı.');
  }
  
  const data = await response.json();
  const pages = data.query.pages;
  const pageId = Object.keys(pages)[0];
  
  if (pageId === '-1') {
    throw new Error('Bu başlığa sahip bir Wikipedia sayfası bulunamadı.');
  }
  
  return pages[pageId].extract;
}

function processText(text) {
  // Convert to lowercase properly using Turkish rules
  const lowerText = text.toLocaleLowerCase('tr-TR');
  // Simple regex to extract words containing alphabet letters including turkish chars
  const words = lowerText.match(/[a-zçğıöşü]+/g) || [];
  
  const wordCounts = {};
  
  for (const word of words) {
    if (word.length > 2 && !stopWords.has(word)) {
      wordCounts[word] = (wordCounts[word] || 0) + 1;
    }
  }
  
  const entries = Object.entries(wordCounts);
  
  // Sort by frequency descending and take top 100 words
  entries.sort((a, b) => b[1] - a[1]);
  
  // Return early if no words
  if (entries.length === 0) return [];
  
  const top100 = entries.slice(0, 100);
  const maxFreq = top100[0][1];
  
  // Normalize sizes against max frequency to avoid huge discrepancies making words overflow bounds
  return top100.map(([word, freq]) => {
    // scale to max standard size
    // return word and desired scale weight
    return [word, freq];
  });
}

function generateCloud(list) {
  // Make sure internal canvas resolution matches visual layout
  canvas.width = canvasContainer.clientWidth;
  canvas.height = canvasContainer.clientHeight;
  
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  if (list.length === 0) {
    showError('Kelime bulutu oluşturmak için yeterli anlamlı metin bulunamadı.');
    return;
  }
  
  // Normalize frequencies so the largest word has a weight of say 40
  const maxFreq = list[0][1];
  const sizeFactor = 60 / maxFreq;

  // WordCloud global object is loaded via CDN script in index.html
  WordCloud(canvas, {
    list: list,
    fontFamily: '"Inter", sans-serif',
    weightFactor: function (size) {
      // Ensure smaller words are also readable.
      // Base size 12px + scaled frequency
      return (size * sizeFactor) + 12;
    },
    color: function() {
      // Light purple / blue neon variants matching dark theme
      const colors = ['#8b5cf6', '#c084fc', '#818cf8', '#38bdf8', '#fb7185', '#e879f9'];
      return colors[Math.floor(Math.random() * colors.length)];
    },
    backgroundColor: 'transparent',
    rotateRatio: 0.2, // Some slanted words look neat
    rotationSteps: 2,
    shape: 'circle',
    drawOutOfBound: false,
    shrinkToFit: true,
    hover: function (item) {
      if (item) {
        canvas.style.cursor = 'pointer';
      } else {
        canvas.style.cursor = 'default';
      }
    }
  });
}

generateBtn.addEventListener('click', async () => {
  const topic = topicInput.value.trim();
  if (!topic) {
    showError('Lütfen bir konu girin.');
    return;
  }
  
  hideError();
  loadingDiv.classList.remove('hidden');
  
  // Clear previous canvas drawing
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  try {
    const text = await fetchWikipediaExtract(topic);
    const wordList = processText(text);
    generateCloud(wordList);
  } catch (err) {
    showError(err.message);
  } finally {
    loadingDiv.classList.add('hidden');
  }
});

topicInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    generateBtn.click();
  }
});
