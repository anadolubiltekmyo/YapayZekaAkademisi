// ========== State ==========
let fetchedImages = [];
let selectedImages = new Set();

// ========== DOM References ==========
const searchInput = document.getElementById('searchInput');
const loadingIndicator = document.getElementById('loadingIndicator');
const errorMessage = document.getElementById('errorMessage');
const resultsSection = document.getElementById('resultsSection');
const resultsTitle = document.getElementById('resultsTitle');
const imageGrid = document.getElementById('imageGrid');
const collageSection = document.getElementById('collageSection');
const collageCanvas = document.getElementById('collageCanvas');

// Enter key triggers search
searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') searchImages();
});

// ========== Search Images ==========
async function searchImages() {
    const query = searchInput.value.trim();
    if (!query) {
        showError('Lütfen bir anahtar kelime girin.');
        return;
    }

    const count = parseInt(document.getElementById('imageCount').value);

    // UI state
    hideError();
    resultsSection.classList.add('hidden');
    collageSection.classList.add('hidden');
    loadingIndicator.querySelector('p').textContent = 'Resimler aranıyor...';
    loadingIndicator.classList.remove('hidden');
    fetchedImages = [];
    selectedImages.clear();

    try {
        const images = await fetchFromWikimedia(query, count);

        if (images.length === 0) {
            showError(`"${query}" için resim bulunamadı. Farklı bir anahtar kelime deneyin.`);
            loadingIndicator.classList.add('hidden');
            return;
        }

        fetchedImages = images;
        // Select all by default
        images.forEach((_, i) => selectedImages.add(i));
        renderImageGrid(images);
        resultsTitle.textContent = `"${query}" için ${images.length} resim bulundu`;
        resultsSection.classList.remove('hidden');
        loadingIndicator.classList.add('hidden');

        // Auto-create collage
        await createCollage();
    } catch (err) {
        console.error('Search error:', err);
        showError('Resimler yüklenirken bir hata oluştu: ' + err.message);
        loadingIndicator.classList.add('hidden');
    }
}

// ========== Wikimedia Commons API ==========
async function fetchFromWikimedia(query, count) {
    const endpoint = 'https://commons.wikimedia.org/w/api.php';
    const params = new URLSearchParams({
        action: 'query',
        generator: 'search',
        gsrsearch: query,
        gsrnamespace: '6', // File namespace
        gsrlimit: String(Math.min(count * 3, 50)), // Fetch more to filter
        prop: 'imageinfo',
        iiprop: 'url|mime',
        iiurlwidth: '400',
        format: 'json',
        origin: '*'
    });

    const url = `${endpoint}?${params}`;
    console.log('Fetching:', url);

    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const data = await response.json();
    console.log('API response:', data);

    if (!data.query || !data.query.pages) return [];

    const pages = Object.values(data.query.pages);
    const images = [];

    for (const page of pages) {
        if (!page.imageinfo || page.imageinfo.length === 0) continue;
        const info = page.imageinfo[0];

        // Only include actual raster images
        if (!info.mime || !info.mime.startsWith('image/')) continue;
        if (info.mime === 'image/svg+xml') continue;
        if (info.mime === 'image/tiff') continue;

        const thumbUrl = info.thumburl || info.url;
        if (!thumbUrl) continue;

        const title = page.title.replace('File:', '').replace(/\.\w+$/, '');

        images.push({
            id: page.pageid,
            title: title,
            thumbUrl: thumbUrl,
            fullUrl: info.url
        });

        if (images.length >= count) break;
    }

    return images;
}

// ========== Render Image Grid ==========
function renderImageGrid(images) {
    imageGrid.innerHTML = '';

    images.forEach((img, index) => {
        const card = document.createElement('div');
        card.className = 'image-card' + (selectedImages.has(index) ? ' selected' : '');
        card.dataset.index = index;

        const imgEl = document.createElement('img');
        imgEl.src = img.thumbUrl;
        imgEl.alt = img.title;
        imgEl.loading = 'lazy';
        imgEl.crossOrigin = 'anonymous';
        imgEl.onerror = function () {
            // If image fails, hide the card
            card.style.display = 'none';
            selectedImages.delete(index);
        };

        const checkBadge = document.createElement('div');
        checkBadge.className = 'check-badge';
        checkBadge.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>`;

        const titleDiv = document.createElement('div');
        titleDiv.className = 'image-title';
        titleDiv.textContent = img.title;

        card.appendChild(imgEl);
        card.appendChild(checkBadge);
        card.appendChild(titleDiv);
        card.addEventListener('click', () => toggleSelection(card, index));
        imageGrid.appendChild(card);
    });
}

// ========== Toggle Selection ==========
function toggleSelection(card, index) {
    if (selectedImages.has(index)) {
        selectedImages.delete(index);
        card.classList.remove('selected');
    } else {
        selectedImages.add(index);
        card.classList.add('selected');
    }
}

function selectAll() {
    document.querySelectorAll('.image-card').forEach((card, i) => {
        selectedImages.add(i);
        card.classList.add('selected');
    });
}

function deselectAll() {
    document.querySelectorAll('.image-card').forEach((card, i) => {
        selectedImages.delete(i);
        card.classList.remove('selected');
    });
}

// ========== Create Collage ==========
async function createCollage() {
    const selected = Array.from(selectedImages).sort((a, b) => a - b);

    if (selected.length < 2) {
        showError('Kolaj oluşturmak için en az 2 resim seçin.');
        return;
    }

    hideError();
    loadingIndicator.querySelector('p').textContent = 'Kolaj oluşturuluyor...';
    loadingIndicator.classList.remove('hidden');

    try {
        // Load all images, skip ones that fail
        const loadResults = await Promise.allSettled(
            selected.map(i => loadImage(fetchedImages[i].thumbUrl))
        );

        const imageElements = loadResults
            .filter(r => r.status === 'fulfilled')
            .map(r => r.value);

        console.log(`Loaded ${imageElements.length} of ${selected.length} images`);

        if (imageElements.length < 2) {
            showError('Yeterli resim yüklenemedi. CORS kısıtlaması olabilir. Lütfen farklı anahtar kelime deneyin.');
            loadingIndicator.classList.add('hidden');
            return;
        }

        const layout = document.getElementById('layoutStyle').value;
        const gap = parseInt(document.getElementById('gapSize').value);

        drawCollage(imageElements, layout, gap);

        collageSection.classList.remove('hidden');

        // Scroll to collage
        collageSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (err) {
        console.error('Collage error:', err);
        showError('Kolaj oluşturulurken bir hata oluştu: ' + err.message);
    } finally {
        loadingIndicator.classList.add('hidden');
        loadingIndicator.querySelector('p').textContent = 'Resimler aranıyor...';
    }
}

// ========== Load Image ==========
function loadImage(url) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';

        const timeout = setTimeout(() => {
            reject(new Error('Image load timeout'));
        }, 15000);

        img.onload = () => {
            clearTimeout(timeout);
            resolve(img);
        };

        img.onerror = () => {
            clearTimeout(timeout);
            console.warn('Failed to load with CORS, trying without:', url);
            // Try without crossOrigin
            const img2 = new Image();
            const timeout2 = setTimeout(() => {
                reject(new Error('Image load timeout (no-cors)'));
            }, 15000);
            img2.onload = () => {
                clearTimeout(timeout2);
                resolve(img2);
            };
            img2.onerror = () => {
                clearTimeout(timeout2);
                reject(new Error(`Failed to load: ${url}`));
            };
            img2.src = url;
        };

        img.src = url;
    });
}

// ========== Draw Collage ==========
function drawCollage(images, layout, gap) {
    const canvas = collageCanvas;
    const ctx = canvas.getContext('2d');
    const count = images.length;

    // Determine grid dimensions
    const cols = Math.ceil(Math.sqrt(count));
    const rows = Math.ceil(count / cols);
    const cellSize = 300;

    const canvasWidth = cols * cellSize + (cols + 1) * gap;
    const canvasHeight = rows * cellSize + (rows + 1) * gap;

    canvas.width = canvasWidth;
    canvas.height = canvasHeight;

    // Background
    ctx.fillStyle = '#1a1a1f';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    if (layout === 'grid') {
        drawGridLayout(ctx, images, cols, rows, cellSize, gap);
    } else if (layout === 'masonry') {
        drawMasonryLayout(ctx, images, cols, cellSize, gap, canvas);
    } else if (layout === 'random') {
        drawRandomLayout(ctx, images, canvasWidth, canvasHeight, cellSize);
    }
}

function drawGridLayout(ctx, images, cols, rows, cellSize, gap) {
    images.forEach((img, i) => {
        const col = i % cols;
        const row = Math.floor(i / cols);
        const x = gap + col * (cellSize + gap);
        const y = gap + row * (cellSize + gap);

        drawImageCover(ctx, img, x, y, cellSize, cellSize);
    });
}

function drawMasonryLayout(ctx, images, cols, cellSize, gap, canvas) {
    const colHeights = new Array(cols).fill(gap);

    images.forEach((img) => {
        const minCol = colHeights.indexOf(Math.min(...colHeights));
        const x = gap + minCol * (cellSize + gap);
        const y = colHeights[minCol];

        const aspectRatio = img.naturalHeight / img.naturalWidth;
        const cellHeight = Math.max(150, Math.min(cellSize * 1.5, cellSize * aspectRatio));

        drawImageCover(ctx, img, x, y, cellSize, cellHeight);
        colHeights[minCol] += cellHeight + gap;
    });

    // Resize canvas to fit content
    const maxHeight = Math.max(...colHeights) + gap;
    const canvasWidth = canvas.width;

    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvasWidth;
    tempCanvas.height = maxHeight;
    const tempCtx = tempCanvas.getContext('2d');
    tempCtx.fillStyle = '#1a1a1f';
    tempCtx.fillRect(0, 0, canvasWidth, maxHeight);

    const colHeights2 = new Array(cols).fill(gap);
    images.forEach((img) => {
        const minCol = colHeights2.indexOf(Math.min(...colHeights2));
        const x = gap + minCol * (cellSize + gap);
        const y = colHeights2[minCol];
        const aspectRatio = img.naturalHeight / img.naturalWidth;
        const cellHeight = Math.max(150, Math.min(cellSize * 1.5, cellSize * aspectRatio));
        drawImageCover(tempCtx, img, x, y, cellSize, cellHeight);
        colHeights2[minCol] += cellHeight + gap;
    });

    canvas.height = maxHeight;
    const newCtx = canvas.getContext('2d');
    newCtx.drawImage(tempCanvas, 0, 0);
}

function drawRandomLayout(ctx, images, canvasWidth, canvasHeight, cellSize) {
    const size = cellSize * 0.8;
    images.forEach((img) => {
        const x = Math.random() * (canvasWidth - size);
        const y = Math.random() * (canvasHeight - size);
        const rotation = (Math.random() - 0.5) * 0.3;

        ctx.save();
        ctx.translate(x + size / 2, y + size / 2);
        ctx.rotate(rotation);

        ctx.shadowColor = 'rgba(0,0,0,0.5)';
        ctx.shadowBlur = 15;
        ctx.shadowOffsetX = 4;
        ctx.shadowOffsetY = 4;

        ctx.fillStyle = '#ffffff';
        const border = 8;
        ctx.fillRect(-size / 2 - border, -size / 2 - border, size + border * 2, size + border * 2);
        ctx.shadowColor = 'transparent';

        drawImageCover(ctx, img, -size / 2, -size / 2, size, size);
        ctx.restore();
    });
}

// ========== Draw Image with Cover ==========
function drawImageCover(ctx, img, x, y, width, height) {
    const imgW = img.naturalWidth || img.width;
    const imgH = img.naturalHeight || img.height;

    if (!imgW || !imgH) {
        // Fallback: draw placeholder
        ctx.fillStyle = '#333';
        ctx.fillRect(x, y, width, height);
        return;
    }

    const imgRatio = imgW / imgH;
    const cellRatio = width / height;

    let sx, sy, sw, sh;

    if (imgRatio > cellRatio) {
        sh = imgH;
        sw = sh * cellRatio;
        sx = (imgW - sw) / 2;
        sy = 0;
    } else {
        sw = imgW;
        sh = sw / cellRatio;
        sx = 0;
        sy = (imgH - sh) / 2;
    }

    try {
        ctx.drawImage(img, sx, sy, sw, sh, x, y, width, height);
    } catch (e) {
        console.warn('drawImage failed:', e);
        ctx.fillStyle = '#333';
        ctx.fillRect(x, y, width, height);
    }
}

// ========== Save Collage ==========
function saveCollage(format) {
    const canvas = collageCanvas;
    const query = searchInput.value.trim() || 'kolaj';

    try {
        const mimeType = format === 'jpeg' ? 'image/jpeg' : 'image/png';
        const quality = format === 'jpeg' ? 0.92 : undefined;

        const dataUrl = canvas.toDataURL(mimeType, quality);
        const link = document.createElement('a');
        link.download = `${query}-kolaj.${format}`;
        link.href = dataUrl;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } catch (e) {
        console.error('Save error (tainted canvas):', e);
        // Fallback: open canvas as blob in new tab
        showError('CORS kısıtlaması nedeniyle doğrudan kaydedilemedi. Resme sağ tıklayıp "Farklı kaydet" seçebilirsiniz.');
    }
}

// ========== Navigation ==========
function backToResults() {
    collageSection.classList.add('hidden');
    resultsSection.classList.remove('hidden');
    resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ========== Helpers ==========
function showError(msg) {
    errorMessage.textContent = msg;
    errorMessage.classList.remove('hidden');
}

function hideError() {
    errorMessage.classList.add('hidden');
}
